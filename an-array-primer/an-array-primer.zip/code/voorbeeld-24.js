let ladekasten = new Array(3); // Alle ladekasten.

let ladekast = new Array(3);   // De eerste kast
ladekasten[0] = ladekast;      // met laden.

ladekast = new Array(3);       // De tweede kast
ladekasten[1] = ladekast;      // met laden.

ladekast = new Array(3);       // De derde kast
ladekasten[2] = ladekast;      // met laden.