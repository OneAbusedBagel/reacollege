let matrixA = [
  [2, 4],
  [1, 3]
];

let matrixB = [
  [5, 2],
  [6, 1]
];