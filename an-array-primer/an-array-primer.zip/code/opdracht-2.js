let mijnInkomsten = new Array(12);

mijnInkomsten[2] =   -64;

mijnInkomsten[3] =   128;

mijnInkomsten[6] = -1024;

mijnInkomsten[9] =  8192;