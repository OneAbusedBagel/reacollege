let afbeelding = [
  [127, 0, 0],   // Een donkerrode pixel.
  [0, 127, 0],   // Een donkergroene pixel.
  // ... (De rest van de afbeelding.)
];