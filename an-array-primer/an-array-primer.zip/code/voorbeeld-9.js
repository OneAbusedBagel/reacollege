let ladeEen  = ladekast[ 0 ];

let ladeTwee = ladekast[ 1 ];

let ladeDrie = ladekast[ 2 ];