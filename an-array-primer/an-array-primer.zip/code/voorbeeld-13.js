let i = 0;
ladekast[ i ] = ladekast[ i ] / 2;

i = 1;
ladekast[ i ] = ladekast[ i ] / 2;

i = 2;
ladekast[ i ] = ladekast[ i ] / 2;