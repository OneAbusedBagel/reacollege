let index = 0;
let ladeEen  = ladekast[ index ];

index = 1;
let ladeTwee = ladekast[ index ];

index = 2;
let ladeDrie = ladekast[ index ];