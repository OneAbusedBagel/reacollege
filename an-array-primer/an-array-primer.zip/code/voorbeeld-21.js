let spreadsheet = [
  ['Naam', 'Leeftijd', 'Woonplaats', 'Inkomen'],
  ['Dirksie', 25, 'Patsverjansdorp', 1250],
  ['Zappolientje', 30, 'Goocheloord', 3100],
  // ... (De rest van de spreadsheet.)
];