ladekast[ 0 ] = 2024;

ladekast[ 1 ] = 11;

ladekast[ 2 ] = 6;