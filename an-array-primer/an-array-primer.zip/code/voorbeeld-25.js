let ladekasten = [  // Alle ladekasten.
  [ 0, 0, 0 ],      // Kast 1 met 3 laden.
  [ 0, 0, 0 ],      // Kast 2 met 3 laden.
  [ 0, 0, 0 ]       // Kast 3 met 3 laden.
];