let ladekasten = new Array(3);

for(let i = 0; i < ladekasten.length; i++) {
  ladekasten[i] = new Array(3);
}