let text = 'That array ate all data!';
for(let i = 0; i < text.length; i++) {
  print(text[i] === 'a' ? 'o' : text[i]);
}