let mijnInkomsten = new Array(12);
let index;

index =  0; mijnInkomsten[index] =    16;
index =  1; mijnInkomsten[index] =    32;
index =  2; mijnInkomsten[index] =   -64;
index =  3; mijnInkomsten[index] =   128;
index =  4; mijnInkomsten[index] =   256;
index =  5; mijnInkomsten[index] =   512;
index =  6; mijnInkomsten[index] = -1024;
index =  7; mijnInkomsten[index] =  2048;
index =  8; mijnInkomsten[index] =  4096;
index =  9; mijnInkomsten[index] =  8192;
index = 10; mijnInkomsten[index] = 16384;
index = 11; mijnInkomsten[index] = 32768;
index = 12; mijnInkomsten[index] = 65536;

printnl(mijnInkomsten);