let tabel = [
  [1, 25, 150, 'Azijn'],
  [2, 30, 200, 'Olijfolie'],
  // ... (De rest van de tabel.)
];