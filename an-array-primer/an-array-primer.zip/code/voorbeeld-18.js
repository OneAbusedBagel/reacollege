let uitgeleend = [
  'Laptop', 'Telefoon',  'Tablet', 'Stylus',
  'Tas',    'USB-stick', 'Muis',   'Headset'
];