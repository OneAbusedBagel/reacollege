ladekast[ 0 ];  // De eerste lade (element).

ladekast[ 1 ];  // De tweede lade (element).

ladekast[ 2 ];  // De derde lade (element).