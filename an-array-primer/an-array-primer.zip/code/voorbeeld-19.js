let schaakbord = [
  ['T', 'R', 'L', 'D', 'K', 'L', 'R', 'T'],
  ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
  // ... (De rest van het schaakbord.)
];