for ( let i = 0; i < ladekast.length; i++ ) {

  ladekast[ i ] = ladekast[ i ] / 2;

}